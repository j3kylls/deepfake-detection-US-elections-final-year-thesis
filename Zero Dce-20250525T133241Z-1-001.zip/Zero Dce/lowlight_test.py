import torch
import torch.nn as nn
import torchvision
import os
import model
import numpy as np
from torchvision import transforms
from PIL import Image
import glob
import time

# Define paths
INPUT_PATHS = ["E:/FAST/mid 2 eval/real", "E:/FAST/mid 2 eval/fake"]
OUTPUT_PATH = "E:/FAST/mid 2 eval/enhanced"

# Ensure output directory exists
os.makedirs(OUTPUT_PATH, exist_ok=True)

# Load Pre-Trained Zero-DCE Model
def load_zero_dce_model():
    model_path = 'snapshots/Epoch99.pth'
    DCE_net = model.enhance_net_nopool().cuda()
    DCE_net.load_state_dict(torch.load(model_path))
    DCE_net.eval()  # Set to evaluation mode
    return DCE_net

# Enhance Image
def lowlight(image_path, output_path, DCE_net):
    """Enhances a low-light image using Zero-DCE"""
    image = Image.open(image_path)
    image = np.asarray(image) / 255.0  # Normalize

    image = torch.from_numpy(image).float()
    image = image.permute(2, 0, 1).unsqueeze(0).cuda()

    start = time.time()
    _, enhanced_image, _ = DCE_net(image)
    end_time = time.time() - start
    print(f"Processed {os.path.basename(image_path)} in {end_time:.2f} sec")

    # Save Enhanced Image
    save_path = os.path.join(output_path, os.path.basename(image_path))
    torchvision.utils.save_image(enhanced_image, save_path)

# Process Dataset
def process_dataset():
    DCE_net = load_zero_dce_model()  # Load model once

    with torch.no_grad():  # No gradient computation (faster)
        for input_folder in INPUT_PATHS:
            category = os.path.basename(input_folder)  # "real" or "fake"
            output_folder = os.path.join(OUTPUT_PATH, category)
            os.makedirs(output_folder, exist_ok=True)

            image_list = glob.glob(os.path.join(input_folder, "*"))
            for image_path in image_list:
                lowlight(image_path, output_folder, DCE_net)

# Run processing
if __name__ == '__main__':
    process_dataset()
